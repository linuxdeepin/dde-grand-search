
// Generated from querylang.g4 by ANTLR 4.7.2


#include "querylangBaseVisitor.h"


